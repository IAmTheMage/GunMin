Metroid
=======

metroid fusion clone in phaser.js

![5](https://cloud.githubusercontent.com/assets/1277379/5471301/4a4476b8-85f4-11e4-8f85-7176c1495f9f.png)
![4](https://cloud.githubusercontent.com/assets/1277379/5471300/4a447a50-85f4-11e4-8f5b-f75248f52ef0.png)
![3](https://cloud.githubusercontent.com/assets/1277379/5471302/4a495476-85f4-11e4-9d36-3c13a25eded3.png)
![2](https://cloud.githubusercontent.com/assets/1277379/5471298/4a40e480-85f4-11e4-9b1c-fd58f38bd8bd.png)
![1](https://cloud.githubusercontent.com/assets/1277379/5471299/4a411586-85f4-11e4-881b-5bab31b9bf97.png)
