#pokemonHTML

This is a proof of concept that the game Pokemon Red by GameFreak could be recreated using today's technology such as HTML5 and Javascript. If everything turns out to be OK, I will continue this project the most I can.

##Usage

To use this project, you can do one of two things:

1. Go to http://jamescastells.github.io/pokemonHTML/. Keep in mind that some images may flicker until they are fully loaded.

2. Download a ZIP file of this project (above, on 'Clone or download', then 'Download ZIP'). Extract all the files and double click on index.html.

#Credits

This project is created by James Castells. If you want to contact me, e-mail me at james_castells@hotmail.com.
