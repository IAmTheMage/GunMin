The *.nes files in this directory are made by other people.
Follow their policies when you use the files.

http://slydogstudios.org/index.php/1k-series/
http://wiki.nesdev.com/w/index.php/Emulator_tests
http://www.mojontwins.com/juegos_mojonos/sgt-helmet-training-day-nes/
