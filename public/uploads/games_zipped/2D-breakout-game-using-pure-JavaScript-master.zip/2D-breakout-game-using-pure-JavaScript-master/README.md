# 2D-breakout-game-using-pure-JavaScript
2D breakout game using pure JavaScript - from MDN tutorial (https://developer.mozilla.org/en-US/docs/Games/Tutorials/2D_Breakout_game_pure_JavaScript)
